/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

/**
 *
 * @author chris
 */
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.List;

public class PlayerWithWalletTest {

    private PlayerWithWallet player;

    @Before
    public void setUp() {
        player = new PlayerWithWallet("John Doe", 1000);
    }
    /*
    * Tests the deduction of money from the wallet.    
    */
    @Test
    public void testDeductFromWallet() {
        player.deductFromWallet(200);
        assertEquals(800, player.getWallet());
        assertEquals(200, player.getCurrentBet());
    }
    /*
    * Tests the INABILITY of deduction of money from the wallet. This test is to show that deduction 
    * will work if subtraction is not within the bounds of the players wallet.
    */
    @Test
    public void testDeductFromWalletInsufficientFunds() {
        player.deductFromWallet(1200);
        assertEquals(1000, player.getWallet());
        assertEquals(0, player.getCurrentBet());
    }
    /*
    * Tests the addition to the wallet.
    */
    @Test
    public void testAddToWallet() {
        player.addToWallet(500);
        assertEquals(1500, player.getWallet());
    }
    /*
    * Tests if the cards in players are set through the setCards function.
    */
    @Test
    public void testSetCards() {
        List<String> cards = Arrays.asList("A of S", "K of H");
        player.setCards(cards);
        assertEquals(cards, player.getCards());
    }
    /*
    * Tests if the toString function replies the string as expected.
    */
    @Test
    public void testToString() {
        String expected = "PlayerWithWallet{name='John Doe', wallet=1000, currentBet=0, cards=[]}";
        assertEquals(expected, player.toString());
    }
}

