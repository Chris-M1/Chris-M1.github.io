package game;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.HashSet;
import java.util.Set;

public class DeckTest {

    private Deck deck;

    @Before
    public void setUp() {
        deck = new Deck();
    }
    
    /*
    *   Tests the correct number of cards are created when creating a deck. 
    */
    @Test
    public void testDeckInitialization() {
        assertEquals(52, deck.getCards().size());

        Set<String> uniqueCards = new HashSet<>(deck.getCards());
        assertEquals(52, uniqueCards.size());
    }
}
