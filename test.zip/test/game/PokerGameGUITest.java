package game;

/**
 *
 * @author chris
 */
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;
import javax.swing.*;
import java.util.List;

public class PokerGameGUITest {

    private PokerGameGUI pokerGameGUI;
    private GameLogic gameLogic;
    private PlayerDAO playerDAO;

    /*
    * Setting up the test conditions. Creating instances of GameLogic, PokerGameGUI and 
    * PlayerDAO, as dependencies on those class are necessary to create a environment to add, edit and delete users that are created.
    */
    @Before
    public void setUp() {
        gameLogic = new GameLogic();
        pokerGameGUI = new PokerGameGUI();
        pokerGameGUI.setVisible(false);  // Hide the GUI during tests
        playerDAO = new PlayerDAO();
    }
    
    /*
    * Two functions created to delete the players that are created in the database from the test.
    */
    @After
    public void tearDown() {
        deleteTestPlayers();
    }

    private void deleteTestPlayers() {
        // Test player names to delete.
        String[] testPlayers = {"Jack", "Johnny"};
        for (String playerName : testPlayers) {
            playerDAO.deletePlayer(playerName);
        }
    }
    
    /*
    * Testing the addition of players to the database. Asserts if the database has the user once entered.
    */
    @Test
    public void testAddPlayer() {
        String playerName = "Jack";
        int initialWallet = 1000;

        pokerGameGUI.getNameField().setText(playerName);
        pokerGameGUI.getWalletField().setText(String.valueOf(initialWallet));
        pokerGameGUI.getAddButton().doClick();

        DefaultListModel<String> listModel = pokerGameGUI.getListModel();
        boolean containsPlayer = listModel.contains(playerName + " - Wallet: $" + initialWallet);
        
        if (!containsPlayer) {
            System.out.println("List Model Contents: " + listModel);
        }
        
        assertTrue(containsPlayer);
    }

    /*
    * Creates a new player and then alters that player's wallet through the alter button on PokerGameGUI
    */
    @Test
    public void testAlterPlayer() {
        String playerName = "Johnny";
        int initialWallet = 1000;
        int newWallet = 2000;

        // Add player
        pokerGameGUI.getNameField().setText(playerName);
        pokerGameGUI.getWalletField().setText(String.valueOf(initialWallet));
        pokerGameGUI.getAddButton().doClick();

        // Select player
        pokerGameGUI.getPlayerList().setSelectedIndex(0);

        // Alter player wallet
        pokerGameGUI.getWalletField().setText(String.valueOf(newWallet));
        pokerGameGUI.getAlterButton().doClick();

        DefaultListModel<String> listModel = pokerGameGUI.getListModel();
        boolean containsUpdatedPlayer = listModel.contains(playerName + " - Wallet: $" + newWallet);
        
        if (!containsUpdatedPlayer) {
            System.out.println("List Model Contents after alter: " + listModel);
        }
        
        assertTrue(containsUpdatedPlayer);
    }
    
    /*
    * Tests the deletion of a new created player through the delete button on PokerGameGUI.
    */
    @Test
    public void testDeletePlayer() {
        String playerName = "John";
        int initialWallet = 1000;

        // Add player
        pokerGameGUI.getNameField().setText(playerName);
        pokerGameGUI.getWalletField().setText(String.valueOf(initialWallet));
        pokerGameGUI.getAddButton().doClick();

        // Select player
        pokerGameGUI.getPlayerList().setSelectedIndex(0);

        // Delete player
        pokerGameGUI.getDeleteButton().doClick();

        DefaultListModel<String> listModel = pokerGameGUI.getListModel();
        boolean containsDeletedPlayer = listModel.contains(playerName + " - Wallet: $" + initialWallet);
        
        if (containsDeletedPlayer) {
            System.out.println("List Model Contents after delete: " + listModel);
        }
        
        assertFalse(containsDeletedPlayer);
    }
}




