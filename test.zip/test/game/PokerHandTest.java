/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

/**
 *
 * @author chris
 */

import game.PokerHand;
import game.PokerHand.HandRank;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.List;

/*
* PokerHandTest is used to test the various functions within PokerHand and PokerHandEvaluator. As these
* Two classes work closely together, the test functions here are used to verify accuracy of the classes 
* on the different handRanks.
*/
public class PokerHandTest {

    /*
    * Tests the programs ability to recognise a set of cards, and the rank from them.
    *
    */
    @Test
    public void testHandRankingRoyalFlush() {
        List<String> cards = Arrays.asList(
            "T of H", "J of H", "Q of H", "K of H", "A of H"
        );
        PokerHand hand = new PokerHand(HandRank.ROYAL_FLUSH, cards);
        assertEquals(HandRank.ROYAL_FLUSH, hand.getRank());
    }
    
    /*
    * Gets the card values, i.e the Number of the card chosen. The cards chosen in this test
    * are ones that use letters, to test values that are not already numbers.
    */
    @Test
    public void testGetCardValues() {
        List<String> cards = Arrays.asList(
            "T of H", "J of H", "Q of H", "K of H", "A of H"
        );
        PokerHand hand = new PokerHand(HandRank.ROYAL_FLUSH, cards);
        List<Integer> cardValues = hand.getCardValues();
        List<Integer> expectedValues = Arrays.asList(10, 11, 12, 13, 14);
        assertEquals(expectedValues, cardValues);
    }
    
    /*
    * This test gets the multiples of the cards, 
    */
    @Test
    public void testGetMultiples() {
        List<String> cards = Arrays.asList(
            "T of H", "T of D", "Q of H", "Q of D", "Q of C"
        );
        PokerHand hand = new PokerHand(HandRank.FULL_HOUSE, cards);
        assertEquals(2, hand.getMultiples().get(10).intValue());
        assertEquals(3, hand.getMultiples().get(12).intValue());
    }
    
    /*
    * This test gets the rank of the multiples, in cases of players getting the same multiples, this is used to choose a
    * winner based on the players ranks, as the higher multiples will win.
    */
    @Test
    public void testGetMultipleRanks() {
        List<String> cards = Arrays.asList(
            "T of H", "T of D", "Q of H", "Q of D", "Q of C"
        );
        PokerHand hand = new PokerHand(HandRank.FULL_HOUSE, cards);
        List<Integer> multipleRanks = hand.getMultipleRanks();
        List<Integer> expectedRanks = Arrays.asList(12, 10);
        assertEquals(expectedRanks, multipleRanks);
    }

    @Test
    public void testGetKickers() {
        List<String> cards = Arrays.asList(
            "T of H", "T of D", "Q of H", "Q of D", "K of C"
        );
    };
};

