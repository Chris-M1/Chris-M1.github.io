/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

/**
 *
 * @author chris
 */
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.sql.SQLException;
import org.junit.After;

/*
* Player Database tester. Tests the initialisation of the database 
* and the addition of a player to the database.
*/
public class PlayerDAOTest {

    private PlayerDAO playerDAO;
    private PlayerWithWallet player;

    @Before
    public void setUp() throws SQLException {
        playerDAO = new PlayerDAO();
        player = new PlayerWithWallet("Chris", 1000);

        // Ensure the database is clean before each test
        playerDAO.deletePlayer(player.getName());
    }
    
    /*
    * Two functions created to delete the players that are created in the database from the test.
    */
    @After
    public void tearDown() {
        deleteTestPlayers();
    }

    private void deleteTestPlayers() {
        // Test player names to delete.
        String[] testPlayers = {"Chris"};
        for (String playerName : testPlayers) {
            playerDAO.deletePlayer(playerName);
        }
    }
    /*
    * Tests if a player can be retrieved through the name, and gets an ID. Names 
    * cannot be the same.
    */
    @Test
    public void testSavePlayerData() throws SQLException {
        playerDAO.addPlayer(player);

        // Retrieve the player by name to get the ID
        PlayerWithWallet retrievedPlayer = (PlayerWithWallet) playerDAO.getPlayerByName(player.getName());

        // Ensure the ID is set correctly
        if (retrievedPlayer == null) {
            fail("Player retrieval failed, retrievedPlayer is null");
        } else {
            player.setId(retrievedPlayer.getId());  // Set the ID on the original player object for verification

            assertEquals(player.getName(), retrievedPlayer.getName());
            assertEquals(player.getWallet(), retrievedPlayer.getWallet());
            assertEquals(player.getId(), retrievedPlayer.getId());  // Verify the ID is correctly set
        }
    }
}

