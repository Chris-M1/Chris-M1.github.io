/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package blackjack;

import static blackjack.Value.ACE;
import static blackjack.Value.EIGHT;
import static blackjack.Value.FIVE;
import static blackjack.Value.FOUR;
import static blackjack.Value.JACK;
import static blackjack.Value.KING;
import static blackjack.Value.NINE;
import static blackjack.Value.QUEEN;
import static blackjack.Value.SEVEN;
import static blackjack.Value.SIX;
import static blackjack.Value.TEN;
import static blackjack.Value.THREE;
import static blackjack.Value.TWO;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Blackjack {
    private Deck deck;
    private Hand playerHand;
    private Hand dealerHand;

    public Blackjack() {
        deck = new Deck();
        deck.shuffle();
        playerHand = new Hand();
        dealerHand = new Hand();
    }

    public void play() {
        // Initial deal
        playerHand.addCard(deck.draw());
        playerHand.addCard(deck.draw());
        dealerHand.addCard(deck.draw());
        dealerHand.addCard(deck.draw());

        System.out.println("Your hand: " + playerHand);
        System.out.println("Dealer's hand: [hidden], " + dealerHand.cards.get(1));

        Scanner scanner = new Scanner(System.in);
        boolean playerTurn = true;
        while (playerTurn) {
            System.out.println("Do you want to (h)it or (s)tand?");
            String action = scanner.nextLine();

            if (action.toLowerCase().equals("h")) {
                playerHand.addCard(deck.draw());
                System.out.println("Your hand: " + playerHand);
                if (playerHand.getScore() > 21) {
                    System.out.println("Bust! Dealer wins.");
                    return;
                }
            } else if (action.toLowerCase().equals("s")) {
                playerTurn = false;
            }
        }

        System.out.println("Dealer's hand: " + dealerHand);
        while (dealerHand.getScore() < 17) {
            dealerHand.addCard(deck.draw());
            System.out.println("Dealer's hand: " + dealerHand);
        }

        if (dealerHand.getScore() > 21 || playerHand.getScore() > dealerHand.getScore()) {
            System.out.println("You win!");
        } else if (playerHand.getScore() < dealerHand.getScore()) {
            System.out.println("Dealer wins!");
        } else {
            System.out.println("It's a tie!");
        }
    }
    
    enum Suit {
    HEARTS, DIAMONDS, CLUBS, SPADES
}

enum Value {
    TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE
}

class Card {
    private Suit suit;
    private Value value;

    public Card(Suit suit, Value value) {
        this.suit = suit;
        this.value = value;
    }

    public Value getValue() {
        return this.value;
    }

    @Override
    public String toString() {
        return this.value + " of " + this.suit;
    }
}

class Deck {
    private ArrayList<Card> cards;

    public Deck() {
        this.cards = new ArrayList<Card>();
        for (Suit suit : Suit.values()) {
            for (Value value : Value.values()) {
                this.cards.add(new Card(suit, value));
            }
        }
    }

    public void shuffle() {
        Collections.shuffle(this.cards);
    }

    public Card draw() {
        return this.cards.remove(0);
    }
}

    class Hand {
    private ArrayList<Card> cards;

    public Hand() {
        this.cards = new ArrayList<>();
    }

    public void addCard(Card card) {
        cards.add(card);
    }

    public int getScore() {
        int score = 0;
        int aceCount = 0;

        for (Card card : cards) {
            switch (card.getValue()) {
                case TWO: score += 2; break;
                case THREE: score += 3; break;
                case FOUR: score += 4; break;
                case FIVE: score += 5; break;
                case SIX: score += 6; break;
                case SEVEN: score += 7; break;
                case EIGHT: score += 8; break;
                case NINE: score += 9; break;
                case TEN:
                case JACK:
                case QUEEN:
                case KING:
                    score += 10; break;
                case ACE:
                    aceCount++; break;
            }
        }

        for (int i = 0; i < aceCount; i++) {
            if (score > 10) {
                score += 1;
            } else {
                score += 11;
            }
        }

        return score;
    }

    @Override
    public String toString() {
        return cards.toString() + " (score: " + getScore() + ")";
    }
}

    public static void main(String[] args) {
        Blackjack game = new Blackjack();
        game.play();
    }
}
