/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blackjack;

class Hand {
    private ArrayList<Card> cards;

    public Hand() {
        this.cards = new ArrayList<>();
    }

    public void addCard(Card card) {
        cards.add(card);
    }

    public int getScore() {
        int score = 0;
        int aceCount = 0;

        for (Card card : cards) {
            switch (card.getValue()) {
                case TWO: score += 2; break;
                case THREE: score += 3; break;
                case FOUR: score += 4; break;
                case FIVE: score += 5; break;
                case SIX: score += 6; break;
                case SEVEN: score += 7; break;
                case EIGHT: score += 8; break;
                case NINE: score += 9; break;
                case TEN:
                case JACK:
                case QUEEN:
                case KING:
                    score += 10; break;
                case ACE:
                    aceCount++; break;
            }
        }

        for (int i = 0; i < aceCount; i++) {
            if (score > 10) {
                score += 1;
            } else {
                score += 11;
            }
        }

        return score;
    }

    @Override
    public String toString() {
        return cards.toString() + " (score: " + getScore() + ")";
    }
}

